/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC3
 */
public class CompaniaAerea {
    
    private String idCompania,nombre,vuelosDisponibles;

    public CompaniaAerea() {
    }

    public CompaniaAerea(String idCompania, String nombre, String vuelosDisponibles) {
        this.idCompania = idCompania;
        this.nombre = nombre;
        this.vuelosDisponibles = vuelosDisponibles;
    }

    public String getIdCompania() {
        return idCompania;
    }

    public void setIdCompania(String idCompania) {
        this.idCompania = idCompania;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getVuelosDisponibles() {
        return vuelosDisponibles;
    }

    public void setVuelosDisponibles(String vuelosDisponibles) {
        this.vuelosDisponibles = vuelosDisponibles;
    }

    @Override
    public String toString() {
        return "CompaniaAerea{" + "idCompania=" + idCompania + ", nombre=" + nombre + ", vuelosDisponibles=" + vuelosDisponibles + '}';
    }
    
    
    
    
}
