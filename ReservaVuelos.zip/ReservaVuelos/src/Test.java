/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC3
 */
public class Test {
    
    public static void main(String[] args) {
        
        
        CompaniaAerea companiaAerea1 = new CompaniaAerea("111", "AVIANCA", "SANTIAGO-BUENOS AIRES, MADRID-TOKIO ");
        Vuelo vuelo1 = new Vuelo("132", "Santiago", "Singapur", "1V,2V,3V,4V",companiaAerea1);
        PasajeroFrecuente pasajeroFrecuente1 = new PasajeroFrecuente("9", 5000);
        Reserva reserva1 = new Reserva(vuelo1, "1V");
        Cliente cliente1 = new Cliente("1111-1", "GARY", reserva1, pasajeroFrecuente1);
        System.out.println(vuelo1.toString());
        System.out.println(companiaAerea1.toString());
        System.out.println(pasajeroFrecuente1.toString());
        System.out.println(reserva1.toString());
        System.out.println(cliente1.toString());
        
        
        
    }
    
}
