/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC3
 */
public class Vuelo {
    
    private String idVuelo,origen,detino,asientosDisponibles;
    private CompaniaAerea companiaArea;

    public Vuelo() {
    }

    public Vuelo(String idVuelo, String origen, String detino, String asientosDisponibles, CompaniaAerea companiaArea) {
        this.idVuelo = idVuelo;
        this.origen = origen;
        this.detino = detino;
        this.asientosDisponibles = asientosDisponibles;
        this.companiaArea = companiaArea;
    }

    public String getIdVuelo() {
        return idVuelo;
    }

    public void setIdVuelo(String idVuelo) {
        this.idVuelo = idVuelo;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDetino() {
        return detino;
    }

    public void setDetino(String detino) {
        this.detino = detino;
    }

    public String getAsientosDisponibles() {
        return asientosDisponibles;
    }

    public void setAsientosDisponibles(String asientosDisponibles) {
        this.asientosDisponibles = asientosDisponibles;
    }

    public CompaniaAerea getCompaniaArea() {
        return companiaArea;
    }

    public void setCompaniaArea(CompaniaAerea companiaArea) {
        this.companiaArea = companiaArea;
    }

    @Override
    public String toString() {
        return "Vuelo{" + "idVuelo=" + idVuelo + ", origen=" + origen + ", detino=" + detino + ", asientosDisponibles=" + asientosDisponibles + ", companiaArea=" + companiaArea + '}';
    }
    
    

   
    
    
    
}
