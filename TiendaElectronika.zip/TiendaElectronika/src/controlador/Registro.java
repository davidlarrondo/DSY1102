/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author david
 */
public class Registro extends bd.Conexion{
    
    
    private String sql ;
    
    public void listar(JTable tabla, DefaultTableModel modelo){
        sql = "SELECT * FROM producto";
        String[] datos = new String[5];
        Connection connect = getConectar();
        
        try {
            Statement st = connect.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                modelo.addRow(datos);
                
            }
            tabla.setModel(modelo);
        } catch (Exception e) {
            System.out.println("ERROR AL INTENTAR LISTAR "+e);
        }finally{
            try {
                connect.close();
            } catch (Exception e) {
                System.out.println("ERROR AL INTENTAR CERRAR LA CONEXIÓN");
            }
        }
    }
    
    public boolean registrar(String nombre, int idCategoria, double precio, int cantidadInventario){
        PreparedStatement ps = null;
        Connection connect = getConectar();
        String query = "INSERT INTO producto (nombre,idCategoria, precio, cantidadInventario) VALUES(?,?,?,?)";
        
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, nombre);
            ps.setInt(2, idCategoria);
            ps.setDouble(3, precio);
            ps.setInt(4, cantidadInventario);
            ps.execute();
            return true;
        } catch (Exception e) {
            System.out.println("ERROR AL INTENTAR REGISTRAR PRODUCTO "+e);
            return false;
        }finally{
            try {
                connect.close();
            } catch (Exception e) {
                System.out.println("ERROR AL INTENTAR CERRAR LA CONEXIÓN");
            }
        }
    }
    
    public void buscar(String idProducto, JTable tabla, DefaultTableModel modelo){
        String sql = "SELECT * FROM producto WHERE idProducto = ?";
        String[] datos = new String[5];
        
        try {
            Connection connect = getConectar();
            PreparedStatement ps = connect.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(idProducto));
            
            ResultSet rs = ps.executeQuery();
            modelo.setRowCount(0);
            
            if (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                modelo.addRow(datos);
                
            }
            tabla.setModel(modelo);
                     
        } catch (Exception e) {
        }
        
        
    }
    
    public boolean eliminar(String idProducto){
        String sql = "DELETE FROM producto WHERE idProducto = ?";
        
        try {
            Connection connect = getConectar();
            PreparedStatement ps = connect.prepareStatement(sql);
            ps.setString(1, idProducto);
            int filaAfectada = ps.executeUpdate();
            
            if (filaAfectada>0) {
                System.out.println("REGISTRO ELIMINADO");
                return true;
                
            }else{
                System.out.println("REGISTRO NO ELIMINADO");
                return false;
                
            }
        } catch (Exception e) {
            System.out.println("ERROR AL ELIMINAR EL REGISTRO "+e);
            return false;
        }
    
    }
    
    public boolean actualizar(int idProducto ,String nombre, int idCategoria, double precio, int cantidadInventario){
        String sql = "UPDATE producto SET nombre = ?, idCategoria = ? , precio =?, cantidadInventario = ? WHERE idProducto =?";
        try {
            Connection connect = getConectar();
            PreparedStatement ps = connect.prepareStatement(sql);
            
            ps.setString(1, nombre);
            ps.setInt(2, idCategoria);
            ps.setDouble(3, precio);
            ps.setInt(4, cantidadInventario);
            ps.setInt(5, idProducto);
            
            int filaAfectada =  ps.executeUpdate();
            return filaAfectada>0;
            
        } catch (Exception e) {
            System.out.println("ERROR AL ACTUALIZAR EL PRODUCTO "+e);
            return false;
        }
    
    }
    
    public void buscarVenta(String idProducto, int cantidad, JTable tabla, DefaultTableModel modelo){
        String sql = "SELECT nombre, precio, cantidadInventario FROM producto WHERE idProducto = ?";
        String[] datos = new String[4];
        
        try {
            Connection connect = getConectar();
            PreparedStatement ps = connect.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(idProducto));
            
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                datos[0] = rs.getString(1); //nombre
                datos[1] = rs.getString(2); //precio
                double precio = rs.getDouble(2);
                int total  = ((int)precio*cantidad);
                datos[2] = String.valueOf(cantidad); //cantidad
                datos[3] = String.valueOf(total); //total
                modelo.addRow(datos);  
            }
            tabla.setModel(modelo);
            
        } catch (Exception e) {
            System.out.println(e);
            
        }
        
    }
    
    public int sumarTotales(JTable tabla){
        
        int totalFinal = 0;
        int columnaTotal = 3;
        
        for (int fila=0; fila<tabla.getRowCount();fila++) {
            Object valor = tabla.getValueAt(fila, columnaTotal);
            if (valor instanceof Number) {
                totalFinal+= ((Number)valor).intValue();
            } else if(valor!=null){
                totalFinal+= Integer.parseInt(valor.toString());
            }
        }
        return totalFinal;
    }
    
 
    

    
    
     
    
    
    
   
    
}
