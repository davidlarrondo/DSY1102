
import java.time.LocalDate;
import java.time.Month;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC4
 */
public class Test {
    
    public static void main(String[] args) {
        
        Revista revista1 = new Revista("K-POP", 001, "123", "MONAS CHINAS", true);
        Revista revista2 = new Revista("ZIG-ZAG", 007, "356", "CONDORITO", true);
        
        revista1.agregarArticulo("SUSHI POKEMON");
        revista1.agregarArticulo("TWICE");
        revista1.listar();
        
        
        LocalDate fechaAcordada1 = LocalDate.of(2024, 10, 01);
        LocalDate fechaAcordada2 = LocalDate.of(2024, 10, 01);
        LocalDate fechaDevolucion1 = LocalDate.of(2024, 10, 03);
        LocalDate fechaDevolucion2 = LocalDate.of(2024, 10, 05);
        Prestamo prestamo1 = new Prestamo(revista1,fechaAcordada1, fechaDevolucion1);
        Prestamo prestamo2 = new Prestamo(revista2,fechaAcordada2, fechaDevolucion2);
        
        Usuario usuario1 = new Usuario("PH ALBA", "PABLO MARMOL");
        usuario1.agregarPrestamo(prestamo1);
        usuario1.agregarPrestamo(prestamo2);
        usuario1.prestamosRealizados();
        System.out.println("MULTA POR DEVOLUCIÓN RETRASADA $"+prestamo1.calcularMulta());
        System.out.println("MULTA POR DEVOLUCIÓN RETRASADA $"+prestamo2.calcularMulta());
        
        
        
        
    }
    
}
