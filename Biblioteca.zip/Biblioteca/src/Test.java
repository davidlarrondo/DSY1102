
import java.util.Date;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Test {
    
    public static void main(String[] args) {
        
        Libro libro1 = new Libro("C.S.LEWIS", "FANTASIA", "123", "LAS CRÓNICAS DE NARNIA", true);
        Libro libro2 = new Libro("J.R.R.TOLKIEN", "FANTASIA", "456", "EL SEÑOR DE LOS ANILLOS", true);
        
        Revista revista1 = new Revista("ALFAGUARA", 123, "333", "CONDORITO", true);
        Revista revista2 = new Revista("XYZ", 456, "777", "NINTENDO", false);
        
        revista1.agregarArticulos("ARTICULO 1");
        revista1.agregarArticulos("ARTICULO 2");
        revista1.listar();
        
        Date fechaPrestamo = new Date(2020, 12, 23);
        Date fechaDevolucion = new Date(2020, 12, 26);
        Usuario usuario1 = new Usuario("678", "CARLOS");
        Prestamo prestamo1 = new Prestamo(revista1, fechaPrestamo, fechaDevolucion);
        usuario1.agregarPrestamo(prestamo1);
        usuario1.listar();
        
        
        
    }
    
}
