
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC4
 */
public class Usuario {
    
    private String idUsuario,nombre;
    private ArrayList<Prestamo> prestamosRealizados;

    public Usuario(String idUsuario, String nombre) {
        this.idUsuario = idUsuario;
        this.nombre = nombre;
        prestamosRealizados = new ArrayList<>();
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Usuario{" + "idUsuario=" + idUsuario + ", nombre=" + nombre + ", prestamosRealizados=" + prestamosRealizados + '}';
    }
    
    public boolean agregarPrestamo(Prestamo prestamo){
        return prestamosRealizados.add(prestamo);
    }
    
    public void prestamosRealizados (){
        System.out.println("PRÉSTAMOS REALIZADOS");
        System.out.println("---------------------");
        for (Prestamo i : prestamosRealizados) {
            System.out.println(i.toString());
        }
        System.out.println("---------------------");
    }
    
    
    
    
}
