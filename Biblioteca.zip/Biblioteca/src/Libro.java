/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Libro extends Material{
    
    private String autor,genero;

    public Libro(String autor, String genero, String idMaterial, String titulo, boolean disponibilidad) {
        super(idMaterial, titulo, disponibilidad);
        this.autor = autor;
        this.genero = genero;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public String toString() {
        return super.toString()+"Libro{" + "autor=" + autor + ", genero=" + genero + '}';
    }
    
    public String obtenerResumen(){
        return "ESTE ES EL RESUMEN";
    }
    
}
