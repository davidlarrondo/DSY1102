
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC4
 */
public class Prestamo {

    private Material material;
    private LocalDate fechaAcordada,fechaDevolucion;

    public Prestamo(Material material, LocalDate fechaAcordada, LocalDate fechaDevolucion) {
        this.material = material;
        this.fechaAcordada = fechaAcordada;
        this.fechaDevolucion = fechaDevolucion;
    }

    public Material getMaterial() {
        return material;
    }

    public void setMaterial(Material material) {
        this.material = material;
    }

    public LocalDate getFechaAcordada() {
        return fechaAcordada;
    }

    public void setFechaAcordada(LocalDate fechaAcordada) {
        this.fechaAcordada = fechaAcordada;
    }

    public LocalDate getFechaDevolucion() {
        return fechaDevolucion;
    }

    public void setFechaDevolucion(LocalDate fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }

    @Override
    public String toString() {
        return "Prestamo{" + "material=" + material + ", fechaAcordada=" + fechaAcordada + ", fechaDevolucion=" + fechaDevolucion + '}';
    }
    
    public double calcularMulta(){
        double multa = 0;
        long diasRetraso = ChronoUnit.DAYS.between(fechaAcordada, fechaDevolucion);
        multa = 1000* diasRetraso;
        
        return multa;
    }
    
    
    
}
