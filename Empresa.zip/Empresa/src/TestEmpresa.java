/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class TestEmpresa {
    
    public static void main(String[] args) {
        
        Puesto puesto1 = new Puesto(1, "GERENTE");
        Puesto puesto2 = new Puesto(2, "EJECUTIVO");
        
        Empleado empleado1 = new Empleado("111", "CARLOS", 'M', 30, 50, puesto1);
        Empleado empleado2 = new Empleado("222", "ELSA", 'F', 40, 60, puesto2);

        Empresa empresa = new Empresa();
        
        //agregamos empleados
        if (empresa.buscarEmpleado("111")==false) {
            empresa.agregar(empleado1);
            System.out.println("SE AGREGÓ EL EMPLEADO "+empleado1.getNombreEmpleado());
        } else {
            System.out.println("EMPLEADO EXISTENTE");
        }
        
        if (empresa.buscarEmpleado("222")==false) {
            empresa.agregar(empleado2);
            System.out.println("SE AGREGÓ EL EMPLEADO "+empleado2.getNombreEmpleado());
        } else {
            System.out.println("EMPLEADO EXISTENTE");
        }
        
        //listar empleados
        empresa.listarEmpleados();
    }
    
}
