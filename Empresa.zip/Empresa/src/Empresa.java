
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Empresa {
    
    private ArrayList<Empleado> listaEmpleados;

    public Empresa() {
        listaEmpleados = new ArrayList<Empleado>();
    }
    
    //agregar
    public boolean agregar(Empleado empleado){
        return listaEmpleados.add(empleado);
    }
    
    //buscar
    public boolean buscarEmpleado(String rut){
        for (Empleado i : listaEmpleados) {
            if (i.getRut().equals(rut)) {
                return true;
            }
        }
        return false;
    }
    
   //listar
    public void listarEmpleados(){
        for (Empleado i : listaEmpleados) {
            System.out.println(i.toString());
        }
    }
    
    //eliminar empleado
    public boolean eliminarEmpleado(String rut){
        for (Empleado i : listaEmpleados) {
            if (i.getRut().equals(rut)) {
                listaEmpleados.remove(i);
                return true;
            }
        }
        return false;
    }
    
    
    
    
    
    
    
}
