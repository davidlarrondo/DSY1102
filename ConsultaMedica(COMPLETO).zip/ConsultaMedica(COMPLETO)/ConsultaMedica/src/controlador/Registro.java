/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import bd.Conexion;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author vina
 */
public class Registro extends Conexion {
    
   String sql = "";

    public Registro() {
    }
    
    public boolean registrar(String rut,String nombre,String genero, boolean donante){
        PreparedStatement ps = null;
        Connection connect = getConectar();
        String query = "INSERT INTO paciente (rut,nombre,genero,donante)"
                + "VALUES (?,?,?,?)";
        try {
            ps = connect.prepareStatement(query);
            ps.setString(1, rut);
            ps.setString(2, nombre);
            ps.setString(3, genero);
            ps.setBoolean(4, donante);
            ps.execute();
            return true;
        } catch (Exception e) {
            System.err.println(e);
            return false;

        }finally{
            try {
                connect.close();
            } catch (Exception e) {
                System.err.println(e);
            }
        }
        
    }
   
   public void listar(JTable tabla, DefaultTableModel modelo){
       
       sql = "SELECT * FROM paciente";
       String [] datos = new String[4];
       
       
       
       try {
           Connection connect = getConectar();
           Statement st = connect.createStatement();
           ResultSet rs = st.executeQuery(sql);
           
           while (rs.next()) {
               datos[0] = rs.getString(1);
               datos[1] = rs.getString(2);
               datos[2] = rs.getString(3);
               datos[3] = rs.getString(4);
               modelo.addRow(datos);  
           }
           tabla.setModel(modelo);
       } catch (Exception e) {
           System.out.println(e);
       }
   }
   
  public boolean eliminar(String rut){
       String sql = "DELETE FROM paciente WHERE rut = ?";
       try {
          Connection connect = getConectar();
          PreparedStatement ps = connect.prepareStatement(sql);
          ps.setString(1, rut);
          int rowsAffected = ps.executeUpdate();
          
           if (rowsAffected>0) {
               System.out.println("REGISTRO ELIMIANDO");   
               return true;
           }else{
               System.out.println("NO SE ENCONTRÓ DICHO RUT");
               return false;
           }
          
      } catch (Exception e) {
           System.out.println("ERROR EL ELIMIUNAR EL REGISTRO"+e.getMessage());
           return false;
      }
  }
  
  public void buscarPorRut(String rut, JTable tabla, DefaultTableModel modelo){
      String sql ="SELECT * FROM paciente WHERE rut = ?";
      String[]datos = new String[4];
      
      try {
          Connection connect = getConectar();
          PreparedStatement ps = connect.prepareStatement(sql);
          ps.setString(1, rut);
          
          ResultSet rs = ps.executeQuery();
          modelo.setRowCount(0);
          
          if (rs.next()) {
              datos[0] = rs.getString(1);
              datos[1] = rs.getString(2);
              datos[2] = rs.getString(3);
              datos[3] = rs.getString(4);
              modelo.addRow(datos);
              
          } else {
              JOptionPane.showMessageDialog(null,"NO SE ENCONTRÓ EL REGISTRO DEL RUT");
          }
          tabla.setModel(modelo);
          
          
      } catch (Exception e) {
          System.out.println("ERROR AL BUSCAR EL PACIENTE"+e.getMessage());
      }
  }
  
  public boolean actualizarPaciente(String rut, String nombre, String genero, boolean donante){
    String sql ="UPDATE paciente SET nombre = ?, genero = ?, donante = ? WHERE rut = ? ";
    
      try {
          Connection connect = getConectar();
          PreparedStatement ps = connect.prepareStatement(sql);
          
          ps.setString(1, nombre);
          ps.setString(2, genero);
          ps.setInt(3,donante ? 1:0 );
          ps.setString(4, rut);
          
          int rowAffected = ps.executeUpdate();
          return rowAffected>0;
          
          
      } catch (Exception e) {
          System.out.println("ERROR EL ACTUALIZAR EL PACIENTE "+e.getMessage());
          return false;
      }

  
  }
  
  
    
}
