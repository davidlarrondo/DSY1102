/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication1;


import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author USRVI-LC3
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        List<String> marcasCopete = new ArrayList<>(); //DECLARAR LISTA E INSTANCIAR
        
        //AGREGAR ELEMENTO AL FINAL DE LA COLECCIÓN
        marcasCopete.add("BOLA 8");
        marcasCopete.add("GATO");
        marcasCopete.add("SANTA HELENA");
        marcasCopete.add("BALTICA");
        marcasCopete.add("DORADA");
        marcasCopete.add("MITJANS");
        
        //MOSTRAR TODOS LOS ELEMENTOS
        for (String i : marcasCopete) {
            System.out.println(i);
        }
        System.out.println("--------------------------");
        
        //AGREGAR UN ELEMENTO EN UNA POSICÓN DETERMINADA
        marcasCopete.add(1, "CASILLERO DEL DIABLO");
        
        //MOSTRAR TODOS LOS ELEMENTOS
        for (String i : marcasCopete) {
            System.out.println(i);
        }
        System.out.println("--------------------------");
        
        
        //BUSCAR VALOR EN UNA COLECCIÓN
        if (marcasCopete.contains("BOLA 8")) {
            System.out.println("EL COPETE ESTÁ EN LA LISTA");
            
        } else {
            System.out.println("EL COPETE NO ESTÁ EN LA LISTA");
        }
        
        //RETORNAR EL VALOR DESDE UNA POSICIÓN
        System.out.println("EL PRIMER VALOR DE LA LISTA ES  "+marcasCopete.get(0));
        
        //ELIMINAR ELEMENTO DESDE SU POSICIÓN
        marcasCopete.remove(3);
        //MOSTRAR TODOS LOS ELEMENTOS
        for (String i : marcasCopete) {
            System.out.println(i);
        }
        System.out.println("--------------------------");
        
        //ELIMINAR ELEMENTO DESDE SU VALOR
        marcasCopete.remove("BALTICA");
        
        //MOSTRAR TODOS LOS ELEMENTOS
        for (String i : marcasCopete) {
            System.out.println(i);
        }
        System.out.println("--------------------------");
        
        //CANTIDAD DE ELEMENTOS EN LA LISTA 
        System.out.println(marcasCopete.size());
        
        //BORRAR TODOS LOS ELEMENTOS
        marcasCopete.clear();
       
        //COMPRAR SI ESTÁ VACÍA
        if (marcasCopete.isEmpty()) {
           System.out.println("LA LISTA ESTÁ VACÍA"); 
        }
        
        
       
        
    }
    
}
