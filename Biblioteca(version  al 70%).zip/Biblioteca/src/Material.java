/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC9
 */
public class Material {
    
    protected String idMaterial,titulo;
    protected boolean disponibilidad; 

    public Material(String idMaterial, String titulo, boolean disponibilidad) {
        this.idMaterial = idMaterial;
        this.titulo = titulo;
        this.disponibilidad = disponibilidad;
    }

    public String getIdMaterial() {
        return idMaterial;
    }

    public void setIdMaterial(String idMaterial) {
        this.idMaterial = idMaterial;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public boolean isDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(boolean disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    @Override
    public String toString() {
        return "Material{" + "idMaterial=" + idMaterial + ", titulo=" + titulo + ", disponibilidad=" + disponibilidad + '}';
    }
    
    public boolean verificarDisponibilidad(){
        return disponibilidad;
    }
    
    
}
