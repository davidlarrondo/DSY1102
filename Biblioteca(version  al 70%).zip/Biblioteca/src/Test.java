
import java.time.LocalDate;
import java.time.Month;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC9
 */
public class Test {
    
    public static void main(String[] args) {
        Libro libro1 = new Libro("C.S.LEWIS", "FANTANSÍA", "123", "LAS CRÓNICAS DE NARNIA", true);
        Libro libro2 = new Libro("MARCELA PAZ", "FANTANSÍA", "456", "PAPELUCHO", true);
        LocalDate fechaPrestamo = LocalDate.of(2024, 10, 1);
        LocalDate fechaDevolucion = LocalDate.of(2024, 10, 3);
        Prestamo prestamo1 = new Prestamo(libro1, fechaPrestamo, fechaDevolucion);
        System.out.println("MULTA A PAGAR $"+prestamo1.calcularMulta());

    }
    
    
    
    
}
