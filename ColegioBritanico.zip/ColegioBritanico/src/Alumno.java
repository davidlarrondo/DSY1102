/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Alumno {
    
    private String nombre,rut,id,nivelIngles,taller;
    private float promedio;

    public Alumno() {
    }

    public Alumno(String nombre, String rut, String id, String nivelIngles, String taller, float promedio) {
        setNombre(nombre);
        this.rut = rut;
        setId(id);
        this.nivelIngles = nivelIngles;
        this.taller = taller;
        this.promedio = promedio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre.length()>=3) {
            this.nombre = nombre;
        } else {
            System.out.println("EL NOMBRE DEBER SER DE 3 CARACTERES COMO MÍNIMO");
        }
        
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id.length()>=8) {
            this.id = id;
        } else {
            System.out.println("DEBE TENER 8 DÍGITOS COMO MÍNIMO");
        }
        
    }

    public String getNivelIngles() {
        return nivelIngles;
    }

    public void setNivelIngles(String nivelIngles) {
        this.nivelIngles = nivelIngles;
    }

    public String getTaller() {
        return taller;
    }

    public void setTaller(String taller) {
        this.taller = taller;
    }

    public float getPromedio() {
        return promedio;
    }

    public void setPromedio(float promedio) {
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return "Alumno{" + "nombre=" + nombre + ", rut=" + rut + ", id=" + id + ", nivelIngles=" + nivelIngles + ", taller=" + taller + ", promedio=" + promedio + '}';
    }
    
    public void editarPromedio(float promedio){
        setPromedio(promedio);
    }
    
    

    
    
    
    
    
}
