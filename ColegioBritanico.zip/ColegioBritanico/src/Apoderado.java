/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Apoderado {
    
    private String nombre,rut,id,formaPago;
    private int totalPagar,hijosMatriculados;
    private Alumno alumno;

    public Apoderado() {
    }

    public Apoderado(String nombre, String rut, String id, String formaPago, int totalPagar, int hijosMatriculados, Alumno alumno) {
        setNombre(nombre);
        this.rut = rut;
        setId(id);
        this.formaPago = formaPago;
        this.totalPagar = totalPagar;
        setHijosMatriculados(hijosMatriculados);
        this.alumno = alumno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre.length()>=3) {
            this.nombre = nombre;
        } else {
            System.out.println("EL NOMBRE DEBER SER DE 3 CARACTERES COMO MÍNIMO");
        }
        
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id.length()>=8) {
            this.id = id;
        } else {
            System.out.println("DEBE TENER 8 DÍGITOS COMO MÍNIMO");
        }
        
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    public int getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(int totalPagar) {
        this.totalPagar = totalPagar;
    }

    public int getHijosMatriculados() {
        return hijosMatriculados;
    }

    public void setHijosMatriculados(int hijosMatriculados) {
        if (hijosMatriculados>=1 && hijosMatriculados<=8) {
            this.hijosMatriculados = hijosMatriculados;
        } else {
            System.out.println("SOLO SE PERMITE ENTRE 3 A 8 ALUMNOS");
        }
        
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    @Override
    public String toString() {
        return "Apoderado{" + "nombre=" + nombre + ", rut=" + rut + ", id=" + id + ", formaPago=" + formaPago + ", totalPagar=" + totalPagar + ", hijosMatriculados=" + hijosMatriculados + ", alumno=" + alumno + '}';
    }
    
    public void mostrarDatos(){
        System.out.println("RESUMEN DE DATOS");
        System.out.println(toString());
    }
    
    public void validarId(){
        if (getId().equalsIgnoreCase(alumno.getId())) {
            System.out.println("ID VALIDADO");
            
        } else {
            System.out.println("ID NO VALIDADO");
        }
    }
    public float obtenerDescuento(){
        float descuento=0;
        if (getFormaPago().equalsIgnoreCase("PAC")) {
            descuento=0.1f;
            if (getHijosMatriculados()>1) {
                descuento=0.15f;
            }
        } else if(getFormaPago().equalsIgnoreCase("CHEQUE")){
            descuento=0.05f;
            if (getHijosMatriculados()>1) {
                descuento=0.1f;
            }
        }
        return descuento;
    }
    
    public void totalPagar(){
        float totalBruto=0,descuento=0,totalConDescuento=0;
        totalBruto= (getHijosMatriculados()*150_000)*10;
        System.out.println("TOTAL BRUTO $"+totalBruto);
        descuento=totalBruto*obtenerDescuento();
        totalConDescuento=totalBruto-descuento;
        this.totalPagar =(int)totalConDescuento; 
        System.out.println("TOTAL FINAL $"+this.totalPagar);
        
        
    }
    
    
    
    
}
