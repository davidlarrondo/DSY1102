/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC9
 */
public class Apoderado {
    
    private String nombre,rut,id,formaPago;
    private int hijosMatriculados,totalPagar;
    private Alumno alumno;

    public Apoderado() {
    }

    public Apoderado(String nombre, String rut, String id, String formaPago, int hijosMatriculados, int totalPagar, Alumno alumno) {
        setNombre(nombre);
        this.rut = rut;
        setId(id);
        this.formaPago = formaPago;
        setHijosMatriculados(hijosMatriculados);
        this.totalPagar = totalPagar;
        this.alumno = alumno;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre.length()>=3) {
            this.nombre = nombre;
        } else {
            System.out.println("El nombre debe tener un largo de 3 caracteres mínimos");
        }
       
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id.length()>=8) {
            this.id = id;
        } else {
            System.out.println("El ID debe tener 8 dígitos al menos");
        }
        
    }

    public String getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(String formaPago) {
        this.formaPago = formaPago;
    }

    public int getHijosMatriculados() {
        return hijosMatriculados;
    }

    public void setHijosMatriculados(int hijosMatriculados) {
        if (hijosMatriculados>=1 && hijosMatriculados<=8) {
            this.hijosMatriculados = hijosMatriculados;
        } else {
            System.out.println("El número de hijos no puede ser menor a 1 ni mayor a 8");
        }
    }

    public int getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(int totalPagar) {
        this.totalPagar = totalPagar;
    }

    public Alumno getAlumno() {
        return alumno;
    }

    public void setAlumno(Alumno alumno) {
        this.alumno = alumno;
    }

    @Override
    public String toString() {
        return "Apoderado{" + "nombre=" + nombre + ", rut=" + rut + ", id=" + id + ", formaPago=" + formaPago + ", hijosMatriculados=" + hijosMatriculados + ", totalPagar=" + totalPagar + ", alumno=" + alumno + '}';
    }
    
    public void mostrarDatos(){
        System.out.println("MOSTRAR DATOS");
        System.out.println(toString());
    }
    
    public void validarId(){
        if (alumno.getId().equalsIgnoreCase(getId())) {
            System.out.println("ID VALIDADO EXITOSAMENTE");
        } else {
            System.out.println("LOS IDS NO SON IGUALES");
        }
        
    }
    
    public float obtenerDescuento(){
        float descuento=0;
        if (getFormaPago().equalsIgnoreCase("PAC")) {
            descuento=0.1f;
            if (getHijosMatriculados()>1) {
                descuento=0.15f;
            }
        } else if (getFormaPago().equalsIgnoreCase("CHEQUE")){
            descuento=0.05f;
            if (getHijosMatriculados()>1) {
                descuento=0.1f;
            }
        }
        return descuento;
    }
    
    public void totalPagar(){
        float totalBruto=0;
        int totalFinal=0;
        int descuentoMoneda=0;
        totalBruto=(150_000*10)*getHijosMatriculados();
        descuentoMoneda=(int)(totalBruto*obtenerDescuento());
        totalFinal=(int)totalBruto-descuentoMoneda;
        setTotalPagar(totalFinal);
        System.out.println("TOTAL A PAGAR $"+getTotalPagar());
    
    }
    
    
    
    
    
            
    
}
