
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author vina
 */
public class Test {
    
    public static void main(String[] args) {
        
        Alumno alumno1 = new Alumno("HERNAN HERMOSILLA", "111", "12345678", "AVANZADO", "ETICA", 3.0f);
        Apoderado apoderado1 = new Apoderado("LUCHO HERMOSILLA", "222", "12345678", "PAC", 500_000, 3, alumno1);
        
        Scanner teclado = new Scanner(System.in);
        int opcion;
        do {   
            System.out.println("(1)MOSTRAR TODOS LOS DATOS");
            System.out.println("(2)VALIDAR ID");
            System.out.println("(3)TOTAL A PAGAR");
            System.out.println("(4)EDITAR PROMEDIO");
            System.out.println("(0)SALIR");
            System.out.println("SELECCIONE OPCIÓN");
            opcion=teclado.nextInt();
                    
            switch (opcion) {
                case 1:
                    apoderado1.mostrarDatos();
                    break;
                case 2:
                    apoderado1.validarId();
                    break;
                case 3:
                    apoderado1.totalPagar();
                    break;
                case 4:
                    alumno1.editarPromedio(4.0f);
                    System.out.println(alumno1.getPromedio());
                    break;
                case 0:
                    break;
                default:
                    System.out.println("OPCIÓN INVÁLIDA");
            }
            
        } while (opcion!=0);
    }
}
