
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC9
 */
public class Test {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        int opcion;
        float nuevoPromedio;
        Alumno alumno1 = new Alumno("ALAN BRITO", "111", "12345678", "BASICO", "FUTBOL", 3.5f);
        Apoderado apoderado1 = new Apoderado("ESTEBAN PIRO", "222", "12345678", "PAC", 3, 150_000, alumno1);
        
        do {            
            System.out.println("(1)VALIDAR ID");
            System.out.println("(2)OBTENER DESCUENTO");
            System.out.println("(3)TOTAL A PAGAR");
            System.out.println("(4)MOSTRAR DATOS");
            System.out.println("(5)EDITAR PROMEDIO");
            System.out.println("(0)SALIR");
            System.out.println("SELECCIONE OPCIÓN ");
            opcion= teclado.nextInt();
            switch (opcion) {
                case 1:
                    apoderado1.validarId();
                    break;
                case 2:
                    System.out.println(apoderado1.obtenerDescuento());
                    break;
                case 3:
                    apoderado1.totalPagar();
                    break;
                case 4:
                    apoderado1.mostrarDatos();
                    break;
                case 5:
                    System.out.println("INGRESE NUEVO PROMEDIO");
                    nuevoPromedio = teclado.nextFloat();
                    alumno1.editarPromedio(nuevoPromedio);
                    break;
                case 0:
                    System.out.println("ADIÓS!");
                    break;
                    
                default:
                    System.out.println("OPCIÓN INVÁLIDA");          
            }
            
        } while (opcion!=0);
        
        
        
        
        
        
        
    }
}
