
import java.time.LocalDate;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USRVI-LC3
 */
public class Test {
        
      public static void main(String[] args) {
          
          LocalDate fechaNacimiento = LocalDate.of(2000, 05, 22);
          LocalDate fechaIngreso = LocalDate.of(1800, 05, 10);
          Alumno alumno1 = new Alumno("222", "PEPE", 18, fechaNacimiento);
          Docente docente1 = new Docente("111", "HERNÁN", "VIÑA DEL MAR", fechaIngreso, 666);
          Asignatura asignatura1 = new Asignatura("123", "BASE DE DATOS", 1.0f, 2.0f, 3.0f, alumno1, docente1);
          System.out.println(asignatura1.toString());
          if (asignatura1.apruebaAsignatura(asignatura1.getNota1(), asignatura1.getNota2(), asignatura1.getNota3())==true)
          {
               System.out.println("APRUEBA ASIGNATURA");
          } else {
              System.out.println("NOS VEMOS EN EL TAV");
          }
          
        
    }
    
    
}
